# Installation

1. Extract all files directly into your main game directory:

.../steamapps/common/WARRIORS OROCHI 4 Ultimate
(GameNative: A:/ disk root)

2. Linux / SteamOS / Winlator Setup:

a. For Armada/GameNative/Winlator
you should set the following environment variable in your game/container properties to ensure the mod DLL loads properly (Armada control -> env -> add):

Name: WINEDLLOVERRIDES
Value: dinput8=n,b

b. for SteamOS
Open up the game properties in your launcher and add `WINEDLLOVERRIDES="dinput8=n,b" %command%` to the launch options.


# In-Game / Container Video Settings

1. Container 1280x720.
2. Set the screen option to Stretch Mode (GameNative/SteamOS GUI)

# Custom Aspect Ratio & FOV
Open WO4U_ARFix.ini (or the corresponding config file) to customize your settings:

[AspectRatio]
; Set your custom target aspect ratio (e.g., 4.0 / 3.0 for 4:3)
TargetWidth = 4.0
TargetHeight = 3.0

[FOV]
; FOV Multiplier (Default: 1.0)
; Lower values result in a wider field of view (e.g., 0.8 recommended for 4:3)
FOVScale = 0.8